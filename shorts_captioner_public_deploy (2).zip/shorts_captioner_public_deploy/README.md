# Shorts Captioner AI — Public Deployment

This package is prepared for deployment on Streamlit Community Cloud. It provides a public browser-based interface, but it does not publish itself automatically: you must put these files in a GitHub repository and connect that repository to Streamlit Community Cloud.

## Deploy it publicly

1. Create or sign in to GitHub.
2. Create a **new public repository** named `shorts-captioner-ai`.
3. Upload the files in this folder (`app.py`, `requirements.txt`, `packages.txt`, and `.gitignore`) to the repository root.
4. Go to https://share.streamlit.io/ and sign in with GitHub.
5. Choose **Create app**, select your repository and branch, and set the main file path to `app.py`.
6. Deploy. Streamlit will build the app and give you a public `https://....streamlit.app` URL.

## Requirements

- The `packages.txt` file asks the Linux build environment to install FFmpeg.
- `requirements.txt` installs Streamlit, faster-whisper, and pandas.
- The first transcription downloads a Whisper model, so first-run processing may take longer.
- Free hosting has CPU, memory, storage, and execution limits. Large videos or multi-hour streams may fail or take a long time. This prototype is intended for short clips, not multi-hour livestream processing.
- Public deployment means other people may be able to use the app. Do not upload private videos or footage you do not have permission to process. The app does not intentionally store uploaded videos in a persistent database, but hosting providers may process data under their own terms.
- This version does not ingest arbitrary YouTube URLs or automatically publish to YouTube. Those need separate authorized ingestion and YouTube API integration.

## Local run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Important

I cannot create the public URL directly from this chat because that requires access to your GitHub account and confirmation of a hosting deployment. Follow the steps above to publish it; once deployed, the hosting service provides the shareable URL.
